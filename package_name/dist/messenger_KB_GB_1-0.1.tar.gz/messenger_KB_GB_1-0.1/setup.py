from setuptools import setup

setup(name="messenger_KB_GB_1",
      version="0.1",
      description="A Simple Math Package",
      author="Kirill Budanov",
      author_email="budanovkirilldmitrievich@gmail.com",
      url="https://github.com/timinglost/JIMgeek",
      packages=["src"]
      )
